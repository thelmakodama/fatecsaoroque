/*jshint browser:true */
/*global $ */(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
 function register_event_handlers()
 {
    
    
     /* button  Next */
    $(document).on("click", ".uib_w_8", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#pagina2"); 
         return false;
    });
    
        /* button  Home */
    
    
        /* button  Prev */
    
    
        /* button  Prev */
    
    
        /* button  Home */
    
    
        /* button  Prev */
    
    
        /* button  Next */
    $(document).on("click", ".uib_w_14", function(evt)
    {
        /* your code goes here */ 
         return false;
    });
    
        /* button  Prev */
    
    
        /* button  Home */
    
    
        /* button  Home */
    $(document).on("click", ".uib_w_12", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#page_95_40"); 
         return false;
    });
    
        /* button  Next */
    $(document).on("click", ".uib_w_14", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#pagina3"); 
         return false;
    });
    
        /* button  Home */
    $(document).on("click", ".uib_w_6", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#page_95_40"); 
         return false;
    });
    
        /* button  Home */
    $(document).on("click", ".uib_w_18", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#page_95_40"); 
         return false;
    });
    
        /* button  Prev */
    $(document).on("click", ".uib_w_19", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#pagina2"); 
         return false;
    });
    
        /* button  Home */
    $(document).on("click", ".uib_w_24", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#page_95_40"); 
         return false;
    });
    
        /* button  Prev */
    $(document).on("click", ".uib_w_25", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#pagina3"); 
         return false;
    });
    
        /* button  Prev */
    $(document).on("click", ".uib_w_13", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#page_95_40"); 
         return false;
    });
    
        /* button  Next */
    $(document).on("click", ".uib_w_20", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#pagina4"); 
         return false;
    });
    
        /* button  Next */
    $(document).on("click", ".uib_w_26", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#pagina5"); 
         return false;
    });
    
        /* button  Home */
    $(document).on("click", ".uib_w_30", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#page_95_40"); 
         return false;
    });
    
        /* button  Prev */
    $(document).on("click", ".uib_w_31", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#pagina4"); 
         return false;
    });
    
        /* button  Next */
    $(document).on("click", ".uib_w_32", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#pagina6"); 
         return false;
    });
    
        /* button  Home */
    $(document).on("click", ".uib_w_36", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#page_95_40"); 
         return false;
    });
    
        /* button  Prev */
    $(document).on("click", ".uib_w_38", function(evt)
    {
         /*global activate_subpage */
         activate_subpage("#pagina5"); 
         return false;
    });
    
    }
 document.addEventListener("app.Ready", register_event_handlers, false);
})();
