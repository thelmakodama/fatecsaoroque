/*jshint browser:true */
/*global $ */(function()
{
 "use strict";
 /*
   hook up event handlers 
 */
 function register_event_handlers()
 {
    
    
     /* button  Começar */
    $(document).on("click", ".uib_w_6", function(evt)
    {
         /*global activate_page */
         activate_page("#pagina1"); 
         return false;
    });
    
        /* button  Proxima */
    $(document).on("click", ".uib_w_15", function(evt)
    {
         /*global activate_page */
         activate_page("#pagina2"); 
         return false;
    });
    
        /* button  Voltar */
    $(document).on("click", ".uib_w_25", function(evt)
    {
         /*global activate_page */
         activate_page("#pagina1"); 
         return false;
    });
    
        /* button  Voltar */
    $(document).on("click", ".uib_w_36", function(evt)
    {
         /*global activate_page */
         activate_page("#pagina2"); 
         return false;
    });
    
        /* button  Proximo */
    $(document).on("click", ".uib_w_26", function(evt)
    {
         /*global activate_page */
         activate_page("#pagina3"); 
         return false;
    });
    
        /* button  Voltar */
    $(document).on("click", ".uib_w_47", function(evt)
    {
         /*global activate_page */
         activate_page("#pagina3"); 
         return false;
    });
    
        /* button  Proxima */
    $(document).on("click", ".uib_w_37", function(evt)
    {
         /*global activate_page */
         activate_page("#pagina4"); 
         return false;
    });
    
        /* button  Finalizar */
    $(document).on("click", ".uib_w_48", function(evt)
    {
         /*global activate_page */
         activate_page("#pagina5"); 
         return false;
    });
    
    }
 document.addEventListener("app.Ready", register_event_handlers, false);
})();
